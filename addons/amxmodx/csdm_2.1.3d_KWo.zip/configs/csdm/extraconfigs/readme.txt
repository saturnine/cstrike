Put extra CSDM config file in here.
You can then make per-map config files using AMX Mod X's map feature. 
For example, make a de_dust.cfg auto-execute file:

csdm_reload csdm\extraconfigs\itemmode.cfg

For more information on how to use per-map config files, see:
http://www.amxmodx.org/forums/viewtopic.php?t=7002